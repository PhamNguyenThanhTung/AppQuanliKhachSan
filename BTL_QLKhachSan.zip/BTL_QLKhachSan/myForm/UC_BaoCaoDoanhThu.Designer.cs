﻿namespace BTL_QLKhachSan.myForm
{
    partial class UC_BaoCaoDoanhThu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelFilter = new System.Windows.Forms.Panel();
            this.btnLoc = new System.Windows.Forms.Button();
            this.lblDenNgay = new System.Windows.Forms.Label();
            this.dtpDenNgay = new System.Windows.Forms.DateTimePicker();
            this.lblTuNgay = new System.Windows.Forms.Label();
            this.dtpTuNgay = new System.Windows.Forms.DateTimePicker();
            this.tabControlBaoCao = new System.Windows.Forms.TabControl();
            this.tabPageTongHop = new System.Windows.Forms.TabPage();
            this.chartDoanhThuTheoThoiGian = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panelKieuBaoCao = new System.Windows.Forms.Panel();
            this.rbTheoNam = new System.Windows.Forms.RadioButton();
            this.rbTheoThang = new System.Windows.Forms.RadioButton();
            this.rbTheoNgay = new System.Windows.Forms.RadioButton();
            this.tabPagePhanTich = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.chartLoaiPhong = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartDichVu = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panelThongKeNhanh = new System.Windows.Forms.Panel();
            this.lblTrungBinh = new System.Windows.Forms.Label();
            this.lblSoHoaDon = new System.Windows.Forms.Label();
            this.lblTongDoanhThu = new System.Windows.Forms.Label();
            this.panelFilter.SuspendLayout();
            this.tabControlBaoCao.SuspendLayout();
            this.tabPageTongHop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartDoanhThuTheoThoiGian)).BeginInit();
            this.panelKieuBaoCao.SuspendLayout();
            this.tabPagePhanTich.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartLoaiPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartDichVu)).BeginInit();
            this.panelThongKeNhanh.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(7, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(331, 32);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "BÁO CÁO DOANH THU";
            // 
            // panelFilter
            // 
            this.panelFilter.Controls.Add(this.lblTitle);
            this.panelFilter.Controls.Add(this.btnLoc);
            this.panelFilter.Controls.Add(this.lblDenNgay);
            this.panelFilter.Controls.Add(this.dtpDenNgay);
            this.panelFilter.Controls.Add(this.lblTuNgay);
            this.panelFilter.Controls.Add(this.dtpTuNgay);
            this.panelFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFilter.Location = new System.Drawing.Point(0, 0);
            this.panelFilter.Name = "panelFilter";
            this.panelFilter.Size = new System.Drawing.Size(940, 70);
            this.panelFilter.TabIndex = 3;
            // 
            // btnLoc
            // 
            this.btnLoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoc.Location = new System.Drawing.Point(813, 20);
            this.btnLoc.Name = "btnLoc";
            this.btnLoc.Size = new System.Drawing.Size(120, 40);
            this.btnLoc.TabIndex = 7;
            this.btnLoc.Text = "Lọc";
            this.btnLoc.UseVisualStyleBackColor = true;
            this.btnLoc.Click += new System.EventHandler(this.btnLoc_Click);
            // 
            // lblDenNgay
            // 
            this.lblDenNgay.AutoSize = true;
            this.lblDenNgay.Location = new System.Drawing.Point(607, 30);
            this.lblDenNgay.Name = "lblDenNgay";
            this.lblDenNgay.Size = new System.Drawing.Size(81, 20);
            this.lblDenNgay.TabIndex = 9;
            this.lblDenNgay.Text = "Đến ngày:";
            // 
            // dtpDenNgay
            // 
            this.dtpDenNgay.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDenNgay.Location = new System.Drawing.Point(694, 26);
            this.dtpDenNgay.Name = "dtpDenNgay";
            this.dtpDenNgay.Size = new System.Drawing.Size(113, 26);
            this.dtpDenNgay.TabIndex = 8;
            // 
            // lblTuNgay
            // 
            this.lblTuNgay.AutoSize = true;
            this.lblTuNgay.Location = new System.Drawing.Point(400, 30);
            this.lblTuNgay.Name = "lblTuNgay";
            this.lblTuNgay.Size = new System.Drawing.Size(69, 20);
            this.lblTuNgay.TabIndex = 7;
            this.lblTuNgay.Text = "Từ ngày:";
            // 
            // dtpTuNgay
            // 
            this.dtpTuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTuNgay.Location = new System.Drawing.Point(475, 26);
            this.dtpTuNgay.Name = "dtpTuNgay";
            this.dtpTuNgay.Size = new System.Drawing.Size(112, 26);
            this.dtpTuNgay.TabIndex = 6;
            // 
            // tabControlBaoCao
            // 
            this.tabControlBaoCao.Controls.Add(this.tabPageTongHop);
            this.tabControlBaoCao.Controls.Add(this.tabPagePhanTich);
            this.tabControlBaoCao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlBaoCao.Location = new System.Drawing.Point(0, 70);
            this.tabControlBaoCao.Name = "tabControlBaoCao";
            this.tabControlBaoCao.SelectedIndex = 0;
            this.tabControlBaoCao.Size = new System.Drawing.Size(940, 530);
            this.tabControlBaoCao.TabIndex = 4;
            // 
            // tabPageTongHop
            // 
            this.tabPageTongHop.Controls.Add(this.chartDoanhThuTheoThoiGian);
            this.tabPageTongHop.Controls.Add(this.panelKieuBaoCao);
            this.tabPageTongHop.Location = new System.Drawing.Point(4, 29);
            this.tabPageTongHop.Name = "tabPageTongHop";
            this.tabPageTongHop.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTongHop.Size = new System.Drawing.Size(932, 497);
            this.tabPageTongHop.TabIndex = 0;
            this.tabPageTongHop.Text = "Doanh Thu Tổng Hợp";
            this.tabPageTongHop.UseVisualStyleBackColor = true;
            // 
            // chartDoanhThuTheoThoiGian
            // 
            chartArea1.Name = "ChartArea1";
            this.chartDoanhThuTheoThoiGian.ChartAreas.Add(chartArea1);
            this.chartDoanhThuTheoThoiGian.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Name = "Legend1";
            this.chartDoanhThuTheoThoiGian.Legends.Add(legend1);
            this.chartDoanhThuTheoThoiGian.Location = new System.Drawing.Point(3, 48);
            this.chartDoanhThuTheoThoiGian.Name = "chartDoanhThuTheoThoiGian";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "DoanhThu";
            this.chartDoanhThuTheoThoiGian.Series.Add(series1);
            this.chartDoanhThuTheoThoiGian.Size = new System.Drawing.Size(926, 446);
            this.chartDoanhThuTheoThoiGian.TabIndex = 10;
            title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title1.Name = "Title1";
            title1.Text = "Biểu đồ doanh thu theo thời gian";
            this.chartDoanhThuTheoThoiGian.Titles.Add(title1);
            // 
            // panelKieuBaoCao
            // 
            this.panelKieuBaoCao.Controls.Add(this.rbTheoNam);
            this.panelKieuBaoCao.Controls.Add(this.rbTheoThang);
            this.panelKieuBaoCao.Controls.Add(this.rbTheoNgay);
            this.panelKieuBaoCao.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelKieuBaoCao.Location = new System.Drawing.Point(3, 3);
            this.panelKieuBaoCao.Name = "panelKieuBaoCao";
            this.panelKieuBaoCao.Size = new System.Drawing.Size(926, 45);
            this.panelKieuBaoCao.TabIndex = 11;
            // 
            // rbTheoNam
            // 
            this.rbTheoNam.AutoSize = true;
            this.rbTheoNam.Location = new System.Drawing.Point(270, 10);
            this.rbTheoNam.Name = "rbTheoNam";
            this.rbTheoNam.Size = new System.Drawing.Size(107, 24);
            this.rbTheoNam.TabIndex = 2;
            this.rbTheoNam.Text = "Theo Năm";
            this.rbTheoNam.UseVisualStyleBackColor = true;
            this.rbTheoNam.CheckedChanged += new System.EventHandler(this.rbKieuBaoCao_CheckedChanged);
            // 
            // rbTheoThang
            // 
            this.rbTheoThang.AutoSize = true;
            this.rbTheoThang.Location = new System.Drawing.Point(135, 10);
            this.rbTheoThang.Name = "rbTheoThang";
            this.rbTheoThang.Size = new System.Drawing.Size(119, 24);
            this.rbTheoThang.TabIndex = 1;
            this.rbTheoThang.Text = "Theo Tháng";
            this.rbTheoThang.UseVisualStyleBackColor = true;
            this.rbTheoThang.CheckedChanged += new System.EventHandler(this.rbKieuBaoCao_CheckedChanged);
            // 
            // rbTheoNgay
            // 
            this.rbTheoNgay.AutoSize = true;
            this.rbTheoNgay.Checked = true;
            this.rbTheoNgay.Location = new System.Drawing.Point(15, 10);
            this.rbTheoNgay.Name = "rbTheoNgay";
            this.rbTheoNgay.Size = new System.Drawing.Size(110, 24);
            this.rbTheoNgay.TabIndex = 0;
            this.rbTheoNgay.TabStop = true;
            this.rbTheoNgay.Text = "Theo Ngày";
            this.rbTheoNgay.UseVisualStyleBackColor = true;
            this.rbTheoNgay.CheckedChanged += new System.EventHandler(this.rbKieuBaoCao_CheckedChanged);
            // 
            // tabPagePhanTich
            // 
            this.tabPagePhanTich.Controls.Add(this.splitContainer1);
            this.tabPagePhanTich.Location = new System.Drawing.Point(4, 29);
            this.tabPagePhanTich.Name = "tabPagePhanTich";
            this.tabPagePhanTich.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePhanTich.Size = new System.Drawing.Size(932, 497);
            this.tabPagePhanTich.TabIndex = 1;
            this.tabPagePhanTich.Text = "Phân Tích Phòng & Dịch Vụ";
            this.tabPagePhanTich.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.chartLoaiPhong);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.chartDichVu);
            this.splitContainer1.Size = new System.Drawing.Size(926, 491);
            this.splitContainer1.SplitterDistance = 459;
            this.splitContainer1.TabIndex = 0;
            // 
            // chartLoaiPhong
            // 
            chartArea2.Name = "ChartArea1";
            this.chartLoaiPhong.ChartAreas.Add(chartArea2);
            this.chartLoaiPhong.Dock = System.Windows.Forms.DockStyle.Fill;
            legend2.Name = "Legend1";
            this.chartLoaiPhong.Legends.Add(legend2);
            this.chartLoaiPhong.Location = new System.Drawing.Point(0, 0);
            this.chartLoaiPhong.Name = "chartLoaiPhong";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series2.Legend = "Legend1";
            series2.Name = "LoaiPhong";
            this.chartLoaiPhong.Series.Add(series2);
            this.chartLoaiPhong.Size = new System.Drawing.Size(459, 491);
            this.chartLoaiPhong.TabIndex = 0;
            title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title2.Name = "Title1";
            title2.Text = "Tỷ trọng doanh thu Loại Phòng";
            this.chartLoaiPhong.Titles.Add(title2);
            // 
            // chartDichVu
            // 
            chartArea3.Name = "ChartArea1";
            this.chartDichVu.ChartAreas.Add(chartArea3);
            this.chartDichVu.Dock = System.Windows.Forms.DockStyle.Fill;
            legend3.Name = "Legend1";
            this.chartDichVu.Legends.Add(legend3);
            this.chartDichVu.Location = new System.Drawing.Point(0, 0);
            this.chartDichVu.Name = "chartDichVu";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
            series3.Legend = "Legend1";
            series3.Name = "DichVu";
            this.chartDichVu.Series.Add(series3);
            this.chartDichVu.Size = new System.Drawing.Size(463, 491);
            this.chartDichVu.TabIndex = 1;
            title3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title3.Name = "Title1";
            title3.Text = "Top dịch vụ sử dụng";
            this.chartDichVu.Titles.Add(title3);
            // 
            // panelThongKeNhanh
            // 
            this.panelThongKeNhanh.Controls.Add(this.lblTrungBinh);
            this.panelThongKeNhanh.Controls.Add(this.lblSoHoaDon);
            this.panelThongKeNhanh.Controls.Add(this.lblTongDoanhThu);
            this.panelThongKeNhanh.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelThongKeNhanh.Location = new System.Drawing.Point(0, 600);
            this.panelThongKeNhanh.Name = "panelThongKeNhanh";
            this.panelThongKeNhanh.Size = new System.Drawing.Size(940, 60);
            this.panelThongKeNhanh.TabIndex = 9;
            // 
            // lblTrungBinh
            // 
            this.lblTrungBinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTrungBinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrungBinh.Location = new System.Drawing.Point(610, 32);
            this.lblTrungBinh.Name = "lblTrungBinh";
            this.lblTrungBinh.Size = new System.Drawing.Size(310, 22);
            this.lblTrungBinh.TabIndex = 11;
            this.lblTrungBinh.Text = "Trung bình / hóa đơn: 0 VND";
            this.lblTrungBinh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSoHoaDon
            // 
            this.lblSoHoaDon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSoHoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoHoaDon.Location = new System.Drawing.Point(610, 8);
            this.lblSoHoaDon.Name = "lblSoHoaDon";
            this.lblSoHoaDon.Size = new System.Drawing.Size(310, 22);
            this.lblSoHoaDon.TabIndex = 10;
            this.lblSoHoaDon.Text = "Số hóa đơn: 0";
            this.lblSoHoaDon.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTongDoanhThu
            // 
            this.lblTongDoanhThu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTongDoanhThu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongDoanhThu.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblTongDoanhThu.Location = new System.Drawing.Point(230, 8);
            this.lblTongDoanhThu.Name = "lblTongDoanhThu";
            this.lblTongDoanhThu.Size = new System.Drawing.Size(350, 46);
            this.lblTongDoanhThu.TabIndex = 9;
            this.lblTongDoanhThu.Text = "Tổng doanh thu: 0 VND";
            this.lblTongDoanhThu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // UC_BaoCaoDoanhThu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.tabControlBaoCao);
            this.Controls.Add(this.panelThongKeNhanh);
            this.Controls.Add(this.panelFilter);
            this.Name = "UC_BaoCaoDoanhThu";
            this.Size = new System.Drawing.Size(940, 660);
            this.Load += new System.EventHandler(this.UC_BaoCaoDoanhThu_Load);
            this.panelFilter.ResumeLayout(false);
            this.panelFilter.PerformLayout();
            this.tabControlBaoCao.ResumeLayout(false);
            this.tabPageTongHop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartDoanhThuTheoThoiGian)).EndInit();
            this.panelKieuBaoCao.ResumeLayout(false);
            this.panelKieuBaoCao.PerformLayout();
            this.tabPagePhanTich.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartLoaiPhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartDichVu)).EndInit();
            this.panelThongKeNhanh.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panelFilter;
        private System.Windows.Forms.Label lblDenNgay;
        private System.Windows.Forms.DateTimePicker dtpDenNgay;
        private System.Windows.Forms.Label lblTuNgay;
        private System.Windows.Forms.DateTimePicker dtpTuNgay;
        private System.Windows.Forms.Button btnLoc;
        private System.Windows.Forms.TabControl tabControlBaoCao;
        private System.Windows.Forms.TabPage tabPageTongHop;
        private System.Windows.Forms.TabPage tabPagePhanTich;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDoanhThuTheoThoiGian;
        private System.Windows.Forms.Panel panelKieuBaoCao;
        private System.Windows.Forms.RadioButton rbTheoNam;
        private System.Windows.Forms.RadioButton rbTheoThang;
        private System.Windows.Forms.RadioButton rbTheoNgay;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartLoaiPhong;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDichVu;
        private System.Windows.Forms.Panel panelThongKeNhanh;
        private System.Windows.Forms.Label lblTrungBinh;
        private System.Windows.Forms.Label lblSoHoaDon;
        private System.Windows.Forms.Label lblTongDoanhThu;
    }
}