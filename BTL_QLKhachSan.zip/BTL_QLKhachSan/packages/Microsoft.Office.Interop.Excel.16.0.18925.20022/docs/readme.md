# Microsoft.Office.Interop.Excel

This is a packaged version of the Interop libraries for Excel. They have been provided by Microsoft as part of the Office SDK and has been repackaged here for NuGet to avoid developers having to install the SDK on each machine they are deploying their solutions to.